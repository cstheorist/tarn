#!/bin/bash
# Start three single-node shards and run the storage protocol tests against
# them (the third is the shard that joins in member_test.lua).
set -u
T=${TARANTOOL:-tarantool}
DIR=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(mktemp -d /tmp/tarn-lua-test.XXXX)
rc=0
if [ -z "${TEST:-}" ]; then
  TARN_METER_DIR="$WORK/lazy-meter" timeout 60 "$T" "$DIR/test/lazy_meter_test.lua" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  timeout 60 "$T" "$DIR/test/vinyl_admission_test.lua" "$WORK/vinyl-admission" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  for test in compat_test clock_guard_test clock_initialization_test membership_freshness_test read_freshness_test native_lua_guard_test native_key_batch_test engine_test engine_terminal_test engine_read_error_test engine_alias_test lazy_codec_test lazy_slice_test lazy_lifecycle_test lazy_concurrency_test lazy_target_confirm_test lazy_apply_confirm_test prepare_confirm_test lazy_native_commit_test lazy_bucket_count_test lazy_plain_binding_test; do
    echo "storage test $test" | tee -a "$WORK/test.out"
    timeout 60 "$T" "$DIR/test/$test.lua" "$WORK/$test" 2>&1 | tee -a "$WORK/test.out"
    r=${PIPESTATUS[0]}
    [ "$r" -ne 0 ] && rc=$r
  done
  for schedule in after-publish during-publish; do
    timeout 60 "$T" "$DIR/test/lazy_registry_test.lua" "$WORK/lazy-registry-$schedule" success "$schedule" 2>&1 | tee -a "$WORK/test.out"
    r=${PIPESTATUS[0]}
    [ "$r" -ne 0 ] && rc=$r
    timeout 60 "$T" "$DIR/test/lazy_metadata_mvcc_test.lua" "$WORK/lazy-metadata-$schedule" "$schedule" 2>&1 | tee -a "$WORK/test.out"
    r=${PIPESTATUS[0]}
    [ "$r" -ne 0 ] && rc=$r
  done
  for boundary in post-reset after-baseline; do
    for engine in memtx vinyl; do
      echo "storage test engine_cut_test $engine $boundary" | tee -a "$WORK/test.out"
      timeout 60 "$T" "$DIR/test/engine_cut_test.lua" "$WORK/engine-cut-$engine-$boundary" "$engine" desired "$boundary" 2>&1 | tee -a "$WORK/test.out"
      r=${PIPESTATUS[0]}
      [ "$r" -ne 0 ] && rc=$r
    done
  done
  TARANTOOL="$T" bash "$DIR/test/member_dependency.sh" "$WORK/member-dependency" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/clock_integration.sh" "$WORK/clock-integration" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/clock_protocol.sh" "$WORK/clock-protocol" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/clock_completion.sh" "$WORK/clock-completion" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  freshness_native=${TARN_NATIVE:-$DIR/../target/release/libtarn_storage.so}
  if [ "$freshness_native" != 0 ] && [ -f "$freshness_native" ]; then
    for control in native handback; do
      NATIVE_FRESHNESS_CONTROL="$control" TARN_NATIVE="$freshness_native" TARANTOOL="$T" \
        bash "$DIR/test/native_freshness.sh" "$WORK/native-freshness-$control" 2>&1 | tee -a "$WORK/test.out"
      r=${PIPESTATUS[0]}
      [ "$r" -ne 0 ] && rc=$r
    done
  elif [ -n "${TARN_NATIVE:-}" ] && [ "$TARN_NATIVE" != 0 ]; then
    echo 'FAIL explicitly requested native freshness module is missing' | tee -a "$WORK/test.out"
    rc=1
  else
    echo 'native freshness RF3 skipped: native disabled' | tee -a "$WORK/test.out"
  fi
  TARANTOOL="$T" bash "$DIR/test/engine_faults.sh" "$WORK/engine-faults" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/engine_replication.sh" "$WORK/engine-rf3" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  for control in source-binding exception stall; do
    ENGINE_RF3_COPY_CONTROL="$control" TARANTOOL="$T" \
      bash "$DIR/test/engine_replication.sh" "$WORK/engine-rf3-$control" 2>&1 | tee -a "$WORK/test.out"
    r=${PIPESTATUS[0]}
    [ "$r" -ne 0 ] && rc=$r
  done
  TARANTOOL="$T" bash "$DIR/test/lazy_faults.sh" "$WORK/lazy-faults" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/lazy_replication.sh" "$WORK/lazy-rf3" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  LAZY_RF3_STATUS_CONTROL=1 LAZY_RF3_REAL_TARANTOOL="$T" \
    TARANTOOL="$DIR/test/lazy_readiness_control.sh" \
    bash "$DIR/test/lazy_replication.sh" "$WORK/lazy-readiness-rf3" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/alter_backfill_faults.sh" "$WORK/backfill" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
  TARANTOOL="$T" bash "$DIR/test/recovery_faults.sh" "$WORK/recovery-faults" 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
fi
P1=${P1:-3511}; P2=${P2:-3512}; P3=${P3:-3513}
PEERS="{\"1\":[\"tarn:tarn@127.0.0.1:$P1\"],\"2\":[\"tarn:tarn@127.0.0.1:$P2\"]}"
for i in 1 2 3; do
  case $i in 1) port=$P1;; 2) port=$P2;; 3) port=$P3;; esac
  # Shard 1 sets vinyl_read_threads; shards 2 and 3 take the default for
  # two instances on this machine.
  TARN_VINYL_READ_THREADS=$([ $i = 1 ] && echo 3) TARN_HOST_INSTANCES=2 \
  TARN_SHARD_ID=$i TARN_LISTEN=127.0.0.1:$port TARN_WORKDIR=$WORK/s$i TARN_PEERS="$PEERS" \
  TARN_MEMORY_MB=256 TARN_LOG_LEVEL=4 TARN_CHECK_YIELDS=1 TARN_TEST_HOOKS=1 TARN_CHECK_LOCKS=1 \
  $T "$DIR/storage.lua" > "$WORK/s$i.log" 2>&1 &
  echo $! > "$WORK/s$i.pid"
done
for p in $P1 $P2 $P3; do for _ in $(seq 50); do (exec 3<>/dev/tcp/127.0.0.1/$p) 2>/dev/null && break; sleep 0.1; done; done
# The port opens before the module has made its schema (tarn.init): a table
# a test makes in between gets another space id on that shard. Wait for it.
for p in $P1 $P2 $P3; do
  for _ in $(seq 100); do
    $T -e "local c = require('net.box').connect('tarn:tarn@127.0.0.1:$p', {wait_connected = 1})
           local ok, r = pcall(c.eval, c, 'return rawget(_G, \"tarn\") ~= nil')
           os.exit((ok and r) and 0 or 1)" < /dev/null > /dev/null 2>&1 && break
    sleep 0.1
  done
done
# The files run in turn on the same shards (each uses its own tables).
for f in ${TEST:-$DIR/test/storage_test.lua $DIR/test/alter_backfill_test.lua $DIR/test/join_test.lua $DIR/test/bucket_test.lua $DIR/test/member_test.lua $DIR/test/rebalance_test.lua $DIR/test/native_test.lua}; do
  echo "storage test $(basename "$f")" | tee -a "$WORK/test.out"
  S1=127.0.0.1:$P1 S2=127.0.0.1:$P2 S3=127.0.0.1:$P3 timeout 120 $T "$f" < /dev/null 2>&1 | tee -a "$WORK/test.out"
  r=${PIPESTATUS[0]}
  [ "$r" -ne 0 ] && rc=$r
done
kill $(cat "$WORK"/s*.pid) 2>/dev/null
# (TARN_CHECK_LOCKS: the native module's copy of the lock index held what the
# index held after every change)
if grep -h "lock copy differs" "$WORK"/s*.log | head -5 | tee -a "$WORK/test.out" | grep -q .; then
  echo "FAIL the native module's copy of the lock index differed from it" | tee -a "$WORK/test.out"
  rc=1
fi
if [ "$rc" -ne 0 ]; then
  echo "--- shard logs ($WORK)"; grep -iE "error|warn" "$WORK"/s*.log | tail -20
  # On GitHub Actions, put the failures in an annotation (job logs are not
  # always at hand; annotations are).
  if [ "${GITHUB_ACTIONS:-}" = true ]; then
    msg=$({ echo "exit code $rc"; grep -E "FAIL|rror" "$WORK/test.out" | head -30; tail -5 "$WORK/test.out"
            echo "--- shard logs"; grep -iE "error|warn" "$WORK"/s*.log | tail -15; } |
          sed 's/%/%25/g; s/\r//g' | sed ':a;N;$!ba;s/\n/%0A/g')
    echo "::error title=Storage protocol tests failed::$msg"
  fi
fi
exit "$rc"
