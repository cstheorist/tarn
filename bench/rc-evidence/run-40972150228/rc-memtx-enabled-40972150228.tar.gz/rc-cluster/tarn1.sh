exec env TARN_LOG=info /tmp/rc-build/tarn-server --config /tmp/rc-cluster/cluster.json --listen 127.0.0.1:4000 --node-id 1 --default-engine memtx >> /tmp/rc-cluster/tarn1.log 2>&1 < /dev/null
