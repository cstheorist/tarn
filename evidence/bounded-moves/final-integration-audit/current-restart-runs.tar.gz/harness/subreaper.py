import ctypes, os, subprocess, sys, time
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0  # PR_SET_CHILD_SUBREAPER
script=sys.stdin.buffer.read()
child=subprocess.Popen(['bash'],stdin=subprocess.PIPE)
child.stdin.write(script); child.stdin.close()
reaped=0
while child.poll() is None:
    try:
        children=open(f'/proc/self/task/{os.getpid()}/children').read().split()
        for pid in map(int,children):
            if pid!=child.pid:
                try:
                    got,_=os.waitpid(pid,os.WNOHANG)
                    reaped += bool(got)
                except ChildProcessError: pass
    except FileNotFoundError: pass
    time.sleep(.02)
print(f'Owned fixture subreaper collected {reaped} orphaned children; shell status {child.returncode}',flush=True)
sys.exit(child.returncode)
