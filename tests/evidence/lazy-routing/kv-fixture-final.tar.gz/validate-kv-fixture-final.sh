#!/bin/bash
set -euo pipefail
export CARGO_PROFILE_RELEASE_LTO=false CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_RELEASE_CODEGEN_UNITS=64
cargo build --offline --locked --release -j1 -p tarn-sql --example strong_kv > /out/build-kv-fixture-final.log 2>&1
python3 tests/sql/kvfaults_test.py > /out/kv-retry-controls-final.log 2>&1
export TARN_SERVER=/out/target/release/tarn-server KV_SDK=/out/target/release/examples/strong_kv
TARN_NATIVE=/out/target/release/libtarn_storage.so tests/kv.sh > /out/kv-fixture-final-native.log 2>&1
TARN_NATIVE=0 tests/kv.sh > /out/kv-fixture-final-lua.log 2>&1
python3 - <<'PY'
from pathlib import Path
import tarfile,json
roots=[]
for name in ('native','lua'):
    text=Path('/out/kv-fixture-final-'+name+'.log').read_text()
    root=Path(next(x.split(': ',1)[1] for x in text.splitlines() if x.startswith('Strong KV evidence: ')))
    lifecycle=json.loads((root/'lifecycle.json').read_text())
    assert lifecycle['exit_code']==0 and lifecycle['owned_processes_reaped'],lifecycle
    roots.append(root)
with tarfile.open('/out/kv-fixture-final.tar.gz','w:gz',compresslevel=1) as tar:
    for root in roots:
        for p in root.rglob('*'):
            if p.is_file() and p.suffix in ('.log','.json','.jsonl'):
                tar.add(p,arcname=str(p.relative_to('/tmp')))
    for p in Path('/out').glob('*kv*final*.log'):
        tar.add(p,arcname=p.name)
    tar.add('/out/validate-kv-fixture-final.sh',arcname='validate-kv-fixture-final.sh')
print('Both native and Lua strong-KV suites passed with retained histories')
PY
