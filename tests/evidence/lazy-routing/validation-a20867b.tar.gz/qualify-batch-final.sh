#!/bin/bash
# Fixed holdout after the separate two-pair batch pilot: five pairs in every
# uniform/skewed 1/4/16-lane case, identical settings, a fresh cluster per case.
set -euo pipefail
export TARN_BIN=/out/target/release/tarn-server TARN_NATIVE=/out/target/release/libtarn_storage.so
export TARN_TEST_HOOKS=1 TARN_VINYL_MEMORY_MB=16 TARN_VINYL_CACHE_MB=0
export TARN_RESOURCE_LIMITS='{"server_bytes":1073741824}'
cluster=''
trap 'if [ -n "$cluster" ]; then KEEP=1 scripts/cluster.sh stop -d "$cluster"; fi' EXIT
mkdir -p /out/qualified-batch-final
for shape in uniform skewed; do
  for lanes in 1 4 16; do
    cluster=/tmp/issue185-batch-final-$shape-$lanes
    scripts/cluster.sh start -n 4 -r 3 -p 4000 -m 96 -w fsync -t 4 -d "$cluster" \
      > "/out/qualified-batch-final/$shape-$lanes-start.log" 2>&1
    python3 - "$cluster" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
for file in root.glob('*.pid'):
    proc=Path('/proc')/file.read_text().strip()
    assert proc.joinpath('stat').read_text().split()[2]!='Z',file
    if file.name.startswith('tarn'):
        assert proc.joinpath('exe').resolve()==Path('/out/target/release/tarn-server'),file
    else:
        assert proc.joinpath('cwd').resolve()==root/file.stem,file
PY
    python3 tests/sql/lazy_routing_cost.py \
      --nodes 127.0.0.1:3311,127.0.0.1:3321,127.0.0.1:3331,127.0.0.1:3341 \
      --cluster-dir "$cluster" --output "/out/qualified-batch-final/$shape-$lanes.json" \
      --pairs 5 --seconds 10 --threads 32 --processes 4 --lanes "$lanes" --shapes "$shape" \
      --write-every 100 --prefix-every 0 --lookup-batch \
      --source a20867b98a772503a89c01d6ee33f929e291ce34 --binary "$TARN_BIN" --native "$TARN_NATIVE" \
      > "/out/qualified-batch-final/$shape-$lanes.log" 2>&1
    KEEP=1 scripts/cluster.sh stop -d "$cluster"
    cluster=''
    echo "Completed batch $shape-$lanes"
  done
done
python3 - <<'PY'
from pathlib import Path
import tarfile
with tarfile.open('/out/batch-final-cluster-logs.tar.gz','w:gz') as t:
    for root in sorted(Path('/tmp').glob('issue185-batch-final-*')):
        for pattern in ('*.log','*.sh','params','cluster.json'):
            for p in sorted(root.glob(pattern)): t.add(p,arcname=root.name+'/'+p.name)
    t.add('/out/qualify-batch-final.sh',arcname='qualify-batch-final.sh')
PY
