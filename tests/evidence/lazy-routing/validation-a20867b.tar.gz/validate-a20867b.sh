#!/bin/bash
set -euo pipefail
export CARGO_PROFILE_RELEASE_LTO=false CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_RELEASE_CODEGEN_UNITS=64
cargo build --offline --locked --release -j1 -p tarn-server -p tarn-storage > /out/build-a20867b.log 2>&1
export TARN_BIN=/out/target/release/tarn-server TARN_NATIVE=/out/target/release/libtarn_storage.so
export TARN_TEST_HOOKS=1 TARN_VINYL_MEMORY_MB=16 TARN_VINYL_CACHE_MB=0
cluster=''
trap 'if [ -n "$cluster" ]; then KEEP=1 scripts/cluster.sh stop -d "$cluster"; fi' EXIT
for engine in memtx vinyl; do
  cluster=/tmp/issue185-a20867b-r2-$engine
  scripts/cluster.sh start -n 2 -r 1 -p 4000 -m 96 -w fsync -t 4 -e "$engine" -d "$cluster" > "/out/start-a20867b-$engine.log" 2>&1
  python3 - "$cluster" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
for file in root.glob('*.pid'):
    proc = Path('/proc')/file.read_text().strip()
    assert proc.joinpath('stat').read_text().split()[2] != 'Z', file
    if file.name.startswith('tarn'):
        assert proc.joinpath('exe').resolve() == Path('/out/target/release/tarn-server'), file
    else:
        assert proc.joinpath('cwd').resolve() == root/file.stem, file
print('Verified every owned process identity and the rebuilt gateway executable')
PY
  python3 tests/sql/lazytest.py --tarn 127.0.0.1:4000 --kv 127.0.0.1:3311,127.0.0.1:3321 --ref 127.0.0.1:3306 --engine "$engine" > "/out/lazy-a20867b-$engine.log" 2>&1
  python3 tests/sql/difftest.py --tarn 127.0.0.1:4000 --ref 127.0.0.1:3306 > "/out/difftest-a20867b-$engine.log" 2>&1
  KEEP=1 scripts/cluster.sh stop -d "$cluster"
  cluster=''
done
LAZY_ROUTE_PARTS=2 bash lua/test/lazy_replication.sh /tmp/issue185-a20867b-rf3 > /out/rf3-a20867b.log 2>&1
python3 - <<'PY'
from pathlib import Path
import tarfile
with tarfile.open('/out/runtime-a20867b.tar.gz','w:gz') as t:
    for p in Path('/out').glob('*a20867b*.log'):
        t.add(p,arcname=p.name)
    for root in Path('/tmp').glob('issue185-a20867b-*'):
        for p in root.rglob('*'):
            if p.is_file() and (p.suffix in ('.log','.sh','.json','.txt') or p.name=='params'):
                t.add(p,arcname=str(p.relative_to('/tmp')))
PY
TARN_NATIVE=0 bash lua/test/lazy_faults.sh /tmp/issue185-a20867b-lua-faults > /out/lazy-faults-a20867b.log 2>&1
echo 'Final merged-source SQL, composite RF3 and movement/restart checks passed'
