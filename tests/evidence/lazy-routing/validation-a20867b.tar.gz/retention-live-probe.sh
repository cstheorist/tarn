#!/bin/bash
set -euo pipefail
cluster=/tmp/issue185-retention-live
export TARN_BIN=/out/target/release/tarn-server TARN_NATIVE=/out/target/release/libtarn_storage.so
export TARN_TEST_HOOKS=1 TARN_VINYL_MEMORY_MB=16 TARN_VINYL_CACHE_MB=0
trap 'KEEP=1 scripts/cluster.sh stop -d "$cluster"' EXIT
scripts/cluster.sh start -n 4 -r 3 -p 4000 -m 96 -w fsync -t 4 -d "$cluster"
python3 - <<'PY'
import sys,json,gzip,hashlib
from pathlib import Path
sys.path.insert(0,'tests/sql')
import lazy_routing_cost as study
original=study.wait_empty
def interrupted(nodes,timeout=10):
    if timeout==30:
        raise TimeoutError('injected post-workload drain failure')
    return original(nodes,timeout)
study.wait_empty=interrupted
nodes='127.0.0.1:3311,127.0.0.1:3321,127.0.0.1:3331,127.0.0.1:3341'
output=Path('/out/retention-live-probe.json')
sys.argv=['probe','--nodes',nodes,'--cluster-dir','/tmp/issue185-retention-live',
          '--output',str(output),'--pairs','1','--seconds','1','--threads','4','--processes','2',
          '--lanes','4','--shapes','skewed','--write-every','100','--prefix-every','0',
          '--source','a20867b98a772503a89c01d6ee33f929e291ce34',
          '--binary','/out/target/release/tarn-server','--native','/out/target/release/libtarn_storage.so']
try:
    study.main()
except TimeoutError as error:
    assert str(error)=='injected post-workload drain failure',error
else:
    raise AssertionError('negative control did not interrupt post-workload drain')
sample=json.loads(output.read_text())['samples'][0]
assert not sample.get('complete') and 'injected post-workload drain failure' in sample['failure']
raw=output.parent/sample['raw_latencies']['path']
assert hashlib.sha256(raw.read_bytes()).hexdigest()==sample['raw_latencies']['sha256']
with gzip.open(raw,'rt') as stream:
    data=json.load(stream)
assert len(data)==4 and all(worker['latencies'] for worker in data)
assert sum(len(worker['latencies']) for worker in data)==sum(worker['completed'] for worker in sample['workers'])
assert all(study.ev(node,"return rawget(_G,'__lazy185')==nil") for node in nodes.split(','))
print('PASS: live post-workload failure retained all four workers and raw samples; hooks restored on all four leaders')
PY
