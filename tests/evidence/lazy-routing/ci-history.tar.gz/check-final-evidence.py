from pathlib import Path
import hashlib,importlib.util,json,tarfile,tempfile
repo=Path('/private/tmp/tarn-issue185');evidence=repo/'tests/evidence/lazy-routing'
spec=importlib.util.spec_from_file_location('summary',repo/'bench/summarize_lazy_routing.py')
summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
expected={}
for name in ('summary-final-ledger.json','summary-batch-final.json','summary-ci-41101768733.json'):
 for report in json.loads((evidence/name).read_text())['reports']:
  expected[report['sha256']]={k:v for k,v in report.items() if k!='path'}
seen=set()
for pattern in ('final-point-*.tar.gz','final-batch-*.tar.gz','ci-41101768733-*.tar.gz'):
 for archive in sorted(evidence.glob(pattern)):
  if archive.name in ('final-point-interruptions.tar.gz','final-batch-pilot.tar.gz'):continue
  with tempfile.TemporaryDirectory(prefix='tarn185-evidence-') as tmp,tarfile.open(archive) as tar:
   root=Path(tmp).resolve();reports=[]
   for member in tar.getmembers():
    if not member.isfile() or not (member.name.endswith('.json') or '.samples/' in member.name):continue
    p=root/member.name
    assert p.resolve().is_relative_to(root),member.name
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(member).read())
    if p.suffix=='.json':
     obj=json.loads(p.read_text())
     if isinstance(obj,dict) and 'arguments' in obj and 'samples' in obj:reports.append(p)
   for report in reports:
    actual=summary.summarize(report);actual.pop('path')
    assert actual==expected[actual['sha256']],archive
    seen.add(actual['sha256'])
assert seen==expected.keys(),(len(seen),len(expected))
formal=json.loads((evidence/'formal-final-307.json').read_text())
with tarfile.open(evidence/'formal-final-307.tar.gz') as tar:
 for case in formal['checks']:
  for name,wanted in case['inputs'].items():
   assert hashlib.sha256((repo/'tla'/name).read_bytes()).hexdigest()==wanted
  output=tar.extractfile('out/'+case['configuration']+'.out').read()
  assert hashlib.sha256(output).hexdigest()==case['output_sha256']
print('PASS: all 30 final benchmark reports reproduce exactly from archives; all 307 formal input/output hashes match')
