#!/bin/bash
set -euo pipefail
mkdir -p /out/qualified-integrated
for shape in uniform skewed; do
  for lanes in 1 4 16; do
    python3 tests/sql/lazy_routing_cost.py \
      --nodes 127.0.0.1:3311,127.0.0.1:3321,127.0.0.1:3331,127.0.0.1:3341 \
      --cluster-dir /tmp/issue185-integrated-qualification --output "/out/qualified-integrated/$shape-$lanes.json" \
      --pairs 5 --seconds 10 --threads 32 --processes 4 --lanes "$lanes" --shapes "$shape" \
      --write-every 100 --prefix-every 0 --source 841aee24f0c5539c02a03e043407fbee817aed8b \
      --binary /out/target/release/tarn-server --native /out/target/release/libtarn_storage.so \
      > "/out/qualified-integrated/$shape-$lanes.log" 2>&1
  done
done
